import logging
from setuptools import setup as setup_base, find_packages, Distribution
from setuptools.command.install import install
from setuptools.command.build_py import build_py
from typing import List, Tuple, Union, Type
import importlib.metadata
import sys
import os
import __main__
import site

# Module Exports
from .builders import CustomBuilder
from .utils import install_local_module, extract_module_name, set_extra_index_url


class BinaryDistribution(Distribution):
    def has_ext_modules(self):
        return True


def write_manifest(additional_dirs: List[str]):
    m_path = os.path.join(os.path.dirname(__main__.__file__), "MANIFEST.in")
    if os.path.exists(m_path):
        os.remove(m_path)

    with open(m_path, "w+") as f:
        for ad in additional_dirs:
            p = os.path.normpath(os.path.relpath(ad, os.path.dirname(m_path)))
            f.write(f"graft {p}\n")


def setup(
            default_name: str,
            default_version: str,
            dependencies: List[str],
            min_python: str = "3.9",
            test_dependencies: List[str] = [],
            custom_builders: List[CustomBuilder] = [],
            fb63_pipy_index: str = "gitlab1.ptb.de/api/v4/groups/387/-/packages/pypi/simple",
            on_install_hook: Union[Type[install], None] = None,
            on_pre_install_hook: Union[Type[build_py], None] = None
        ) -> None:
    name = default_name
    version = default_version
    cmdclass = {}
    opts = {}

    logging.getLogger().setLevel(logging.INFO)

    logging.info(f"Commandline parameters: {sys.argv}")

    logging.info(f"Set additional index-url: {fb63_pipy_index}")
    set_extra_index_url(fb63_pipy_index)

    if os.environ.get("CI_COMMIT_TAG") is not None:
        version = os.environ.get("CI_COMMIT_TAG")

    if "--version" in sys.argv:
        v_idx = sys.argv.index("--version")
        version = sys.argv[v_idx+1]
        sys.argv.pop(v_idx)
        sys.argv.pop(v_idx)

    if "--name" in sys.argv:
        n_idx = sys.argv.index("--name")
        name = sys.argv[n_idx+1]
        sys.argv.pop(n_idx)
        sys.argv.pop(n_idx)

    if "sphinx" in sys.modules:
        logging.info("Found sphinx!")
        from sphinx.setup_command import BuildDoc
        cmdclass.update({
            'build_sphinx': BuildDoc
        })
        opts.update({
                'build_sphinx': {
                'project': ('setup.py', name),
                'version': ('setup.py', version),
                'release': ('setup.py', version + ".0"),
                'source_dir': ('setup.py', 'docs')}
            })
        
    if on_install_hook is not None:
        cmdclass.update({
            'install': on_install_hook,
        })

    if on_pre_install_hook is not None:
        cmdclass.update({
            'build_py': on_pre_install_hook
        })

    additional_folders = []
    ext_modules: List[Tuple[str, str]] = []
    distclass = None
    for builder in custom_builders:
        builder.run()
        additional_folders.append(builder.get_build_out_dir())
        if builder.get_binary_path() is not None:
            ext_modules.append((default_name if builder.get_build_name() is None else builder.get_build_name(), builder.get_binary_path()))
    if len(additional_folders) > 0:
        write_manifest(additional_folders)

    if len(ext_modules) > 0:
        distclass = BinaryDistribution

    extras = {
        'test': test_dependencies,
    }

    install_dependencies = []
    for dep in dependencies:
        local_path = None
        dep_name = extract_module_name(dep)

        if '@' in dep:
            l = dep.split("@")
            local_path = l[1].strip()
            local_path = os.path.join(os.path.dirname(__main__.__file__), local_path) if not os.path.isabs(local_path) else local_path
            dep = l[0].strip()
        try:
            _ = __import__(dep_name)
            mod_path = importlib.metadata.distribution(dep_name)._path
            mod_path = os.path.normpath(mod_path)
            site_path = os.path.normpath(site.getsitepackages())
            if site_path not in mod_path:
                logging.warn(f"Skipping dependency {dep} since it is already installed in development mode!")
                continue
            else:
                # Else update module:
                if local_path is None:
                    install_dependencies.append(dep)
                else:
                    install_local_module(dep_name, local_path)
                    logging.info(f"Successfully installed fb63module '{dep_name}'")
        except Exception or ModuleNotFoundError or ImportError:
            if local_path is None:
                install_dependencies.append(dep)
            else:
                install_local_module(dep_name, local_path)
                logging.info(f"Successfully installed fb63module '{dep_name}'")

    should_include_data_files = os.path.exists(os.path.join(os.path.dirname(__main__.__file__), "MANIFEST.in"))
    should_include_data_files = should_include_data_files or (len(additional_folders) > 0)

    packages = find_packages()
    package_data = {}
    if len(ext_modules) > 0:
        packages = list(set(packages + [m[0] for m in ext_modules]))
        for m in ext_modules:
            if m[0] not in package_data.keys():
                package_data[m[0]] = []
            logging.info(f"Pack asset: {m[1]}")
            package_data[m[0]].append(m[1])

    setup_base(
        name=name,
        packages=packages,
        version=version,
        author="AG 6.35",
        license='None',
        long_description=open('README.md').read() if os.path.exists('README.md') else "",
        install_requires=install_dependencies,
        python_requires=">=" + min_python,
        extras_require=extras,
        cmdclass=cmdclass,
        command_options=opts,
        package_dir={},
        package_data=package_data,
        include_package_data=should_include_data_files,
        distclass=distclass
    )
