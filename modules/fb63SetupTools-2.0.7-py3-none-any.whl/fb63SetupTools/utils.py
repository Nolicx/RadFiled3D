import sys
import os
import subprocess
import importlib
import re
import logging

PIPYPKGPATTERN = re.compile(r"\<a\ href\=\"([^\"]+)\"[^\>]+\>([^\<]+)<\/a>")
MODULEVERSIONPATTERN = re.compile(r"[^\-]+\-([^\-]+)\-py3[^\.]+\.whl")


def add_login_to_url(url: str) -> str:
    user = os.environ.get("pipy_user")
    if user is None:
        logging.warning("No pipy_user environment variable set!")
    token = os.environ.get("pipy_token")
    return url.replace("https://", f"https://{user}:{token}@")


def get_tokenized_index_url(index_url: str) -> str:
    if "https://" not in index_url:
        index_url = f"https://{index_url}"
    tokenized_index_url = add_login_to_url(index_url)
    return tokenized_index_url


def set_extra_index_url(index_url: str):
    try:
        subprocess.check_call([
                sys.executable,
                "-m", "pip",
                "config",
                "set",
                "global.extra-index-url", get_tokenized_index_url(index_url)
            ],
            cwd=os.getcwd(),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
    except:
        logging.warning(f"Could not set extra index url to 'https://{index_url}'!")
        pass


def extract_module_name(module: str) -> str:
    if '@' in module:
        module = module.split("@")[0].strip()
    # Extract module name when version hints are provided
    if "==" in module:
        return module.split("==")[0].strip()
    if ">=" in module:
        return module.split(">=")[0].strip()
    if ">" in module:
        return module.split(">")[0].strip()
    if "<=" in module:
        return module.split("<=")[0].strip()
    if "<" in module:
        return module.split("<")[0].strip()
    return module


def install_fb63module(module: str, index_url: str):
    tokenized_index_url = get_tokenized_index_url(index_url)
    try:
        subprocess.check_call([
                sys.executable,
                "-m", "pip",
                "install",  module,
                "--index-url", tokenized_index_url
            ],
            cwd=os.getcwd(),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
    except:
        raise Exception(f"Could not install module '{module}' from 'https://{index_url}'!")
    
    module_ref = importlib.find_loader(module)
    if module_ref is None:
        raise Exception(f"Pip has not installed module '{module}' from 'https://{index_url}'!")


def install_local_module(module: str, path: str):
    try:
        subprocess.check_call([
                sys.executable,
                "-m", "pip",
                "install", path
            ],
            cwd=os.getcwd(),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
    except:
        raise Exception(f"Could not install module '{module}' from '{path}'!")
    
    module_ref = importlib.find_loader(module)
    if module_ref is None:
        raise Exception(f"Pip has not installed module '{module}' from '{path}'!")
