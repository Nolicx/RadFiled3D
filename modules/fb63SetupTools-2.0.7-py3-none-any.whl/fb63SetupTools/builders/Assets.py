from .CustomBuilder import CustomBuilder
import os


class StaticAssetFile(CustomBuilder):
    def __init__(self, file: str) -> None:
        super().__init__()
        self.file = file

    def run(self) -> None:
        pass

    def get_build_out_dir(self) -> str:
        return os.path.dirname(self.file)
    
    def get_binary_path(self) -> str:
        return self.file

    def get_build_name(self) -> str:
        return None


class StaticAssetDirectory(CustomBuilder):
    def __init__(self, directory: str) -> None:
        super().__init__()
        self.directory = directory

    def run(self) -> None:
        pass

    def get_build_out_dir(self) -> str:
        return self.directory
    
    def get_binary_path(self) -> str:
        return None

    def get_build_name(self) -> str:
        return None
