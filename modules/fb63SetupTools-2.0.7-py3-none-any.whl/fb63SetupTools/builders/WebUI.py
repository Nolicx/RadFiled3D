from .CustomBuilder import CustomBuilder
from typing import List
from enum import Enum
import subprocess
import re
import __main__
import os
import warnings


class BuildWebUI(CustomBuilder):
    """ Command that can build preparated webpages
    """
    class Bundler(Enum):
        Framework7Vite = 0
        Webpack = 1
        Vuetify = 2

    _target_dir: str = ""
    _out_dir: str = ""

    def __init__(self, target_dir: str, bundler: Bundler) -> None:
        self._target_dir = os.path.join(os.path.dirname(__main__.__file__), target_dir) if not os.path.isabs(target_dir) else target_dir
        if bundler == BuildWebUI.Bundler.Framework7Vite:
            self._out_dir = os.path.join(self._target_dir, "www")
        elif bundler == BuildWebUI.Bundler.Webpack:
            self._out_dir = os.path.join(self._target_dir, "dist")
            try:
                config_txt = open(os.path.join(self._target_dir, "webpack.config.js")).read()
                pattern = re.compile(r"output\s*\:\s*\{([^\}]+)\}")
                output_section = pattern.findall(config_txt)[0][0]
                pattern = re.compile(r"path\.resolve\(__dirname, \"([^\"]*)\"\)")
                out_folder = pattern.findall(output_section)[0][0]
                self._out_dir = os.path.join(self._target_dir, out_folder)
            except:
                pass
        elif bundler == BuildWebUI.Bundler.Vuetify:
            self._out_dir = os.path.join(self._target_dir, "dist")

    def run(self):
        try:
            subprocess.check_call("npm -v", shell=True)
            subprocess.check_call("npm install", cwd=self._target_dir, shell=True)
            subprocess.check_call("npm run build", cwd=self._target_dir, shell=True)
        except Exception as e:
            warnings.warn("Skipping webui build! Consider installing npm+nodejs (https://nodejs.org/en/download/)\n" + str(e))

    @staticmethod
    def list_files_recursive(dir: str, files: List[str] = []) -> List[str]:
        for f in os.listdir(dir):
            files.append(os.path.join(dir, f))
            if os.path.isdir(files[-1]):
                files = BuildWebUI.list_files_recursive(files[-1], files)
        return files

    def get_build_out_dir(self) -> str:
        return self._out_dir
