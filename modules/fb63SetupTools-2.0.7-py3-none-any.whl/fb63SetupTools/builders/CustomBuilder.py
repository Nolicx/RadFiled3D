class CustomBuilder:
    def run(self) -> None:
        raise Exception("Unimplemented run()")

    def get_build_out_dir(self) -> str:
        raise Exception("Unimplemented get_build_out_dir()")
    
    def get_binary_path(self) -> str:
        return None

    def get_build_name(self) -> str:
        return None
